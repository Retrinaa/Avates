import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  boolean,
  json,
  int,
  bigint,
} from "drizzle-orm/mysql-core";

export const newsArticles = mysqlTable("news_articles", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 500 }).notNull(),
  content: text("content"),
  url: varchar("url", { length: 1000 }).notNull(),
  source: varchar("source", { length: 255 }).notNull(),
  category: varchar("category", { length: 100 }),
  imageUrl: varchar("image_url", { length: 1000 }),
  publishedAt: timestamp("published_at").notNull(),
  fetchedAt: timestamp("fetched_at").defaultNow().notNull(),
  isProcessed: boolean("is_processed").default(false).notNull(),
  summary: text("summary"),
});

export const agentPosts = mysqlTable("agent_posts", {
  id: serial("id").primaryKey(),
  newsId: bigint("news_id", { mode: "number", unsigned: true }).references(() => newsArticles.id),
  content: text("content").notNull(),
  rawNewsTitle: varchar("raw_news_title", { length: 500 }),
  reactionType: varchar("reaction_type", { length: 50 }).notNull(), // hot_take, analysis, joke, doom, bullish
  sentiment: mysqlEnum("sentiment", ["bullish", "bearish", "neutral", "chaotic"]).default("neutral").notNull(),
  telegramMessageId: varchar("telegram_message_id", { length: 255 }),
  postedAt: timestamp("posted_at").defaultNow().notNull(),
  engagementScore: int("engagement_score").default(0),
});

export const agentConfigs = mysqlTable("agent_configs", {
  id: serial("id").primaryKey(),
  key: varchar("key", { length: 255 }).notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const agentLogs = mysqlTable("agent_logs", {
  id: serial("id").primaryKey(),
  level: mysqlEnum("level", ["info", "warn", "error", "debug"]).default("info").notNull(),
  message: text("message").notNull(),
  metadata: json("metadata"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const newsSources = mysqlTable("news_sources", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  url: varchar("url", { length: 1000 }).notNull(),
  type: mysqlEnum("type", ["rss", "api"]).default("rss").notNull(),
  category: varchar("category", { length: 100 }),
  isActive: boolean("is_active").default(true).notNull(),
  lastFetchedAt: timestamp("last_fetched_at"),
  fetchIntervalMinutes: int("fetch_interval_minutes").default(30),
});

export const scheduledPosts = mysqlTable("scheduled_posts", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  newsId: bigint("news_id", { mode: "number", unsigned: true }).references(() => newsArticles.id),
  scheduledAt: timestamp("scheduled_at").notNull(),
  postedAt: timestamp("posted_at"),
  status: mysqlEnum("status", ["pending", "posted", "failed", "cancelled"]).default("pending").notNull(),
  errorMessage: text("error_message"),
});

export type NewsArticle = typeof newsArticles.$inferSelect;
export type InsertNewsArticle = typeof newsArticles.$inferInsert;
export type AgentPost = typeof agentPosts.$inferSelect;
export type InsertAgentPost = typeof agentPosts.$inferInsert;
export type AgentConfig = typeof agentConfigs.$inferSelect;
export type InsertAgentConfig = typeof agentConfigs.$inferInsert;
export type AgentLog = typeof agentLogs.$inferSelect;
export type InsertAgentLog = typeof agentLogs.$inferInsert;
export type NewsSource = typeof newsSources.$inferSelect;
export type InsertNewsSource = typeof newsSources.$inferInsert;
export type ScheduledPost = typeof scheduledPosts.$inferSelect;
export type InsertScheduledPost = typeof scheduledPosts.$inferInsert;
