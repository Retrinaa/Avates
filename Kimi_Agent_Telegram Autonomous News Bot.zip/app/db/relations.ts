import { relations } from "drizzle-orm";
import { newsArticles, agentPosts, scheduledPosts } from "./schema";

export const newsArticlesRelations = relations(newsArticles, ({ many }) => ({
  posts: many(agentPosts),
  scheduledPosts: many(scheduledPosts),
}));

export const agentPostsRelations = relations(agentPosts, ({ one }) => ({
  news: one(newsArticles, {
    fields: [agentPosts.newsId],
    references: [newsArticles.id],
  }),
}));

export const scheduledPostsRelations = relations(scheduledPosts, ({ one }) => ({
  news: one(newsArticles, {
    fields: [scheduledPosts.newsId],
    references: [newsArticles.id],
  }),
}));
