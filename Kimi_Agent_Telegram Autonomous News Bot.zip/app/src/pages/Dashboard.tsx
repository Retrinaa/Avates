import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Activity, Newspaper, MessageSquare, Terminal, Play, Square, RefreshCw, Zap, Bot, Radio } from "lucide-react";

export default function Dashboard() {
  const utils = trpc.useUtils();
  const [activeTab, setActiveTab] = useState("overview");

  const { data: status } = trpc.agent.status.useQuery();
  const { data: news } = trpc.agent.newsList.useQuery({ limit: 20 });
  const { data: posts } = trpc.agent.postList.useQuery({ limit: 20 });
  const { data: logs } = trpc.agent.logList.useQuery({ limit: 50 });

  const fetchNews = trpc.agent.fetchNews.useMutation({
    onSuccess: () => {
      utils.agent.newsList.invalidate();
      utils.agent.unprocessedNews.invalidate();
    },
  });

  const runCycle = trpc.agent.runCycle.useMutation({
    onSuccess: () => {
      utils.agent.postList.invalidate();
      utils.agent.newsList.invalidate();
      utils.agent.logList.invalidate();
    },
  });

  const startScheduler = trpc.agent.startScheduler.useMutation({
    onSuccess: () => utils.agent.status.invalidate(),
  });

  const stopScheduler = trpc.agent.stopScheduler.useMutation({
    onSuccess: () => utils.agent.status.invalidate(),
  });

  const generateReaction = trpc.agent.generateReaction.useMutation({
    onSuccess: () => {
      utils.agent.postList.invalidate();
      utils.agent.newsList.invalidate();
    },
  });

  const isSchedulerRunning = status?.scheduler?.hasCronJob;

  const sentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case "bullish": return "bg-green-500/20 text-green-400 border-green-500/30";
      case "bearish": return "bg-red-500/20 text-red-400 border-red-500/30";
      case "chaotic": return "bg-purple-500/20 text-purple-400 border-purple-500/30";
      default: return "bg-blue-500/20 text-blue-400 border-blue-500/30";
    }
  };

  const reactionEmoji = (type: string) => {
    switch (type) {
      case "hot_take": return "🔥";
      case "analysis": return "🧠";
      case "joke": return "😂";
      case "doom": return "💀";
      case "bullish": return "📈";
      case "chaotic": return "⚡";
      default: return "💬";
    }
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      {/* Header */}
      <header className="border-b border-neutral-800 bg-neutral-950/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold tracking-tight">AVA Agent</h1>
              <p className="text-xs text-neutral-400">Autonomous AI News Reactor</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className={isSchedulerRunning ? "border-green-500/50 text-green-400" : "border-neutral-700 text-neutral-400"}>
              <Radio className="w-3 h-3 mr-1" />
              {isSchedulerRunning ? "Running" : "Stopped"}
            </Badge>
            <Badge variant="outline" className="border-neutral-700 text-neutral-400">
              <Activity className="w-3 h-3 mr-1" />
              {status?.telegramConfigured ? "Telegram" : "No Bot"}
            </Badge>
            <Badge variant="outline" className="border-neutral-700 text-neutral-400">
              <Zap className="w-3 h-3 mr-1" />
              {status?.openaiConfigured ? "AI" : "Fallback"}
            </Badge>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        {/* Control Panel */}
        <Card className="mb-6 border-neutral-800 bg-neutral-900/50">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center gap-3">
              <Button
                variant={isSchedulerRunning ? "destructive" : "default"}
                size="sm"
                onClick={() => isSchedulerRunning ? stopScheduler.mutate() : startScheduler.mutate()}
                disabled={startScheduler.isPending || stopScheduler.isPending}
              >
                {isSchedulerRunning ? <Square className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                {isSchedulerRunning ? "Stop Scheduler" : "Start Scheduler"}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => fetchNews.mutate()}
                disabled={fetchNews.isPending}
                className="border-neutral-700"
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${fetchNews.isPending ? "animate-spin" : ""}`} />
                Fetch News
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => runCycle.mutate()}
                disabled={runCycle.isPending}
                className="border-neutral-700"
              >
                <Zap className="w-4 h-4 mr-2" />
                Run Cycle
              </Button>
              <div className="text-xs text-neutral-500 ml-auto">
                Next run: {status?.scheduler?.nextRun || "N/A"}
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="bg-neutral-900 border border-neutral-800">
            <TabsTrigger value="overview" className="data-[state=active]:bg-neutral-800">
              <Activity className="w-4 h-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="news" className="data-[state=active]:bg-neutral-800">
              <Newspaper className="w-4 h-4 mr-2" />
              News ({news?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="posts" className="data-[state=active]:bg-neutral-800">
              <MessageSquare className="w-4 h-4 mr-2" />
              Reactions ({posts?.length || 0})
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-neutral-800">
              <Terminal className="w-4 h-4 mr-2" />
              Logs
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="border-neutral-800 bg-neutral-900/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-400">Latest News</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {news?.slice(0, 10).map((article) => (
                        <div key={article.id} className="p-3 rounded-lg bg-neutral-800/50 hover:bg-neutral-800 transition-colors">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-sm font-medium line-clamp-2">{article.title}</p>
                            <Badge variant="outline" className="shrink-0 text-xs border-neutral-700">
                              {article.source}
                            </Badge>
                          </div>
                          <p className="text-xs text-neutral-500 mt-1">
                            {new Date(article.publishedAt).toLocaleString()}
                          </p>
                          {article.isProcessed && (
                            <Badge className="mt-2 text-xs bg-green-500/20 text-green-400 border-green-500/30">
                              Processed
                            </Badge>
                          )}
                        </div>
                      ))}
                      {!news?.length && (
                        <p className="text-sm text-neutral-500 text-center py-8">No news yet. Click Fetch News.</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="border-neutral-800 bg-neutral-900/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-400">Latest Reactions</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {posts?.slice(0, 10).map((post) => (
                        <div key={post.id} className="p-3 rounded-lg bg-neutral-800/50">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-lg">{reactionEmoji(post.reactionType)}</span>
                            <Badge variant="outline" className={`text-xs ${sentimentColor(post.sentiment)}`}>
                              {post.sentiment}
                            </Badge>
                            <Badge variant="outline" className="text-xs border-neutral-700">
                              {post.reactionType}
                            </Badge>
                          </div>
                          <p className="text-sm">{post.content}</p>
                          <p className="text-xs text-neutral-500 mt-1">
                            {new Date(post.postedAt).toLocaleString()}
                          </p>
                        </div>
                      ))}
                      {!posts?.length && (
                        <p className="text-sm text-neutral-500 text-center py-8">No reactions yet.</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card className="border-neutral-800 bg-neutral-900/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-neutral-400">Agent Logs</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2 font-mono text-xs">
                      {logs?.slice(0, 20).map((log, i) => (
                        <div key={i} className="flex items-start gap-2 p-2 rounded bg-neutral-800/30">
                          <span className={`shrink-0 ${
                            log.level === "error" ? "text-red-400" :
                            log.level === "warn" ? "text-yellow-400" :
                            log.level === "debug" ? "text-blue-400" : "text-green-400"
                          }`}>
                            [{log.level.toUpperCase()}]
                          </span>
                          <span className="text-neutral-300">{log.message}</span>
                          <span className="text-neutral-600 ml-auto shrink-0">
                            {new Date(log.createdAt).toLocaleTimeString()}
                          </span>
                        </div>
                      ))}
                      {!logs?.length && (
                        <p className="text-sm text-neutral-500 text-center py-8">No logs yet.</p>
                      )}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* News Tab */}
          <TabsContent value="news">
            <Card className="border-neutral-800 bg-neutral-900/50">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {news?.map((article) => (
                    <div key={article.id} className="p-4 rounded-lg bg-neutral-800/50 border border-neutral-700/50">
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <h3 className="font-medium mb-1">{article.title}</h3>
                          <p className="text-sm text-neutral-400 line-clamp-2 mb-2">
                            {article.content || "No summary available"}
                          </p>
                          <div className="flex items-center gap-2 text-xs text-neutral-500">
                            <Badge variant="outline" className="text-xs border-neutral-700">{article.source}</Badge>
                            <span>{article.category}</span>
                            <span>•</span>
                            <span>{new Date(article.publishedAt).toLocaleString()}</span>
                          </div>
                        </div>
                        <div className="flex flex-col gap-2">
                          {article.isProcessed ? (
                            <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Processed</Badge>
                          ) : (
                            <Button
                              size="sm"
                              variant="outline"
                              className="border-neutral-700"
                              onClick={() => generateReaction.mutate({ newsId: article.id })}
                              disabled={generateReaction.isPending}
                            >
                              <Zap className="w-3 h-3 mr-1" />
                              React
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                  {!news?.length && (
                    <div className="text-center py-12">
                      <Newspaper className="w-12 h-12 text-neutral-700 mx-auto mb-4" />
                      <p className="text-neutral-500">No news articles fetched yet.</p>
                      <Button
                        variant="outline"
                        className="mt-4 border-neutral-700"
                        onClick={() => fetchNews.mutate()}
                        disabled={fetchNews.isPending}
                      >
                        <RefreshCw className={`w-4 h-4 mr-2 ${fetchNews.isPending ? "animate-spin" : ""}`} />
                        Fetch News Now
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Posts Tab */}
          <TabsContent value="posts">
            <Card className="border-neutral-800 bg-neutral-900/50">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {posts?.map((post) => (
                    <div key={post.id} className="p-4 rounded-lg bg-neutral-800/50 border border-neutral-700/50">
                      <div className="flex items-start gap-3">
                        <div className="text-2xl">{reactionEmoji(post.reactionType)}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className={`text-xs ${sentimentColor(post.sentiment)}`}>
                              {post.sentiment}
                            </Badge>
                            <Badge variant="outline" className="text-xs border-neutral-700">
                              {post.reactionType}
                            </Badge>
                            {post.telegramMessageId && (
                              <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
                                Telegram
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm mb-2">{post.content}</p>
                          {post.rawNewsTitle && (
                            <p className="text-xs text-neutral-500 mb-2">
                              On: {post.rawNewsTitle}
                            </p>
                          )}
                          <p className="text-xs text-neutral-600">
                            {new Date(post.postedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                  {!posts?.length && (
                    <div className="text-center py-12">
                      <MessageSquare className="w-12 h-12 text-neutral-700 mx-auto mb-4" />
                      <p className="text-neutral-500">No reactions posted yet.</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Logs Tab */}
          <TabsContent value="logs">
            <Card className="border-neutral-800 bg-neutral-900/50">
              <CardContent className="p-6">
                <ScrollArea className="h-[600px]">
                  <div className="space-y-2 font-mono text-sm">
                    {logs?.map((log, i) => (
                      <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-neutral-800/30 border border-neutral-800">
                        <span className={`shrink-0 font-bold ${
                          log.level === "error" ? "text-red-400" :
                          log.level === "warn" ? "text-yellow-400" :
                          log.level === "debug" ? "text-blue-400" : "text-green-400"
                        }`}>
                          [{log.level.toUpperCase()}]
                        </span>
                        <div className="flex-1">
                          <p className="text-neutral-300">{log.message}</p>
                          {(() => {
                            const meta = log.metadata;
                            if (meta && typeof meta === "object") {
                              return (
                                <p className="text-xs text-neutral-600 mt-1">
                                  {JSON.stringify(meta)}
                                </p>
                              );
                            }
                            return null;
                          })()}
                        </div>
                        <span className="text-neutral-600 shrink-0 text-xs">
                          {new Date(log.createdAt).toLocaleString()}
                        </span>
                      </div>
                    ))}
                    {!logs?.length && (
                      <p className="text-neutral-500 text-center py-12">No logs available.</p>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
}
