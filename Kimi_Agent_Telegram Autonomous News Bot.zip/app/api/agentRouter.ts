import { z } from "zod";
import { createRouter, publicQuery } from "./middleware";
import { getRecentNews, getNewsById } from "./queries/news";
import { getRecentPosts, getPostById, getPostsByNewsId, createAgentPost } from "./queries/posts";
import { getRecentLogs, createLog } from "./queries/logs";
import { getConfig, setConfig, getAllConfigs } from "./queries/config";
import { fetchAllNews, getUnprocessedNews, markNewsProcessed, seedDefaultSources } from "./services/news";
import { generateReaction } from "./services/aiPersonality";
import { initTelegramBot, postToTelegram } from "./services/telegram";
import { startScheduler, stopScheduler, runAgentCycle, getSchedulerStatus } from "./services/scheduler";

export const agentRouter = createRouter({
  // News
  newsList: publicQuery
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }).optional())
    .query(({ input }) => getRecentNews(input?.limit ?? 50)),

  newsById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(({ input }) => getNewsById(input.id)),

  unprocessedNews: publicQuery
    .input(z.object({ limit: z.number().min(1).max(20).default(10) }).optional())
    .query(({ input }) => getUnprocessedNews(input?.limit ?? 10)),

  fetchNews: publicQuery
    .mutation(async () => {
      await seedDefaultSources();
      const count = await fetchAllNews();
      await createLog({ level: "info", message: `Manual fetch: ${count} articles` });
      return { count };
    }),

  // Posts / Reactions
  postList: publicQuery
    .input(z.object({ limit: z.number().min(1).max(100).default(50) }).optional())
    .query(({ input }) => getRecentPosts(input?.limit ?? 50)),

  postById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(({ input }) => getPostById(input.id)),

  postsByNewsId: publicQuery
    .input(z.object({ newsId: z.number() }))
    .query(({ input }) => getPostsByNewsId(input.newsId)),

  generateReaction: publicQuery
    .input(z.object({
      newsId: z.number(),
      preferredType: z.enum(["hot_take", "analysis", "joke", "doom", "bullish", "chaotic"]).optional(),
    }))
    .mutation(async ({ input }) => {
      const news = await getNewsById(input.newsId);
      if (!news) throw new Error("News not found");

      const reaction = await generateReaction(
        news.title,
        news.content || "",
        news.category,
        input.preferredType
      );

      const post = await createAgentPost({
        newsId: news.id,
        content: reaction.content,
        rawNewsTitle: news.title,
        reactionType: reaction.reactionType,
        sentiment: reaction.sentiment as any,
      });

      await markNewsProcessed(news.id);
      return { post, reaction };
    }),

  postToTelegram: publicQuery
    .input(z.object({
      postId: z.number(),
    }))
    .mutation(async ({ input }) => {
      const post = await getPostById(input.postId);
      if (!post) throw new Error("Post not found");

      const messageId = await postToTelegram(post.content, post.newsId ?? undefined);
      return { success: !!messageId, messageId };
    }),

  // Logs
  logList: publicQuery
    .input(z.object({ limit: z.number().min(1).max(200).default(100) }).optional())
    .query(({ input }) => getRecentLogs(input?.limit ?? 100)),

  // Config
  configList: publicQuery.query(() => getAllConfigs()),

  configGet: publicQuery
    .input(z.object({ key: z.string() }))
    .query(({ input }) => getConfig(input.key)),

  configSet: publicQuery
    .input(z.object({ key: z.string(), value: z.string() }))
    .mutation(({ input }) => setConfig(input.key, input.value)),

  // Agent Control
  startBot: publicQuery.mutation(async () => {
    await initTelegramBot();
    return { success: true };
  }),

  startScheduler: publicQuery.mutation(async () => {
    startScheduler();
    await createLog({ level: "info", message: "Scheduler started manually" });
    return { success: true };
  }),

  stopScheduler: publicQuery.mutation(async () => {
    stopScheduler();
    await createLog({ level: "info", message: "Scheduler stopped manually" });
    return { success: true };
  }),

  runCycle: publicQuery.mutation(async () => {
    await runAgentCycle();
    return { success: true };
  }),

  status: publicQuery.query(() => ({
    scheduler: getSchedulerStatus(),
    telegramConfigured: !!process.env.TELEGRAM_BOT_TOKEN,
    openaiConfigured: !!process.env.OPENAI_API_KEY,
  })),
});
