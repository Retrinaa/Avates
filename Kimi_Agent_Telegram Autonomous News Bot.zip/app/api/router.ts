import { createRouter, publicQuery } from "./middleware";
import { agentRouter } from "./agentRouter";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  agent: agentRouter,
});

export type AppRouter = typeof appRouter;
