import Parser from "rss-parser";
import { getDb } from "../queries/connection";
import { newsArticles, newsSources, type InsertNewsArticle } from "@db/schema";
import { eq, and, gte, desc } from "drizzle-orm";

const rssParser = new Parser({
  timeout: 10000,
  headers: {
    "User-Agent": "AVA-Agent/1.0 (News Aggregator)",
  },
});

const DEFAULT_SOURCES = [
  {
    name: "TechCrunch",
    url: "https://techcrunch.com/feed/",
    type: "rss" as const,
    category: "tech",
    isActive: true,
    fetchIntervalMinutes: 30,
  },
  {
    name: "The Verge",
    url: "https://www.theverge.com/rss/index.xml",
    type: "rss" as const,
    category: "tech",
    isActive: true,
    fetchIntervalMinutes: 30,
  },
  {
    name: "CoinDesk",
    url: "https://www.coindesk.com/arc/outboundfeeds/rss/",
    type: "rss" as const,
    category: "crypto",
    isActive: true,
    fetchIntervalMinutes: 20,
  },
  {
    name: "Ars Technica",
    url: "https://feeds.arstechnica.com/arstechnica/index",
    type: "rss" as const,
    category: "tech",
    isActive: true,
    fetchIntervalMinutes: 30,
  },
  {
    name: "Hacker News",
    url: "https://hnrss.org/frontpage?points=100",
    type: "rss" as const,
    category: "tech",
    isActive: true,
    fetchIntervalMinutes: 15,
  },
  {
    name: "AI News",
    url: "https://news.ycombinator.com/rss",
    type: "rss" as const,
    category: "ai",
    isActive: true,
    fetchIntervalMinutes: 20,
  },
];

export async function seedDefaultSources() {
  const db = getDb();
  const existing = await db.select().from(newsSources);
  if (existing.length === 0) {
    await db.insert(newsSources).values(DEFAULT_SOURCES);
  }
}

export async function fetchNewsFromSource(source: typeof newsSources.$inferSelect) {
  try {
    const feed = await rssParser.parseURL(source.url);
    const items: InsertNewsArticle[] = [];

    for (const item of feed.items.slice(0, 10)) {
      if (!item.title || !item.link) continue;

      const pubDate = item.pubDate ? new Date(item.pubDate) : new Date();
      if (isNaN(pubDate.getTime())) continue;

      items.push({
        title: item.title.slice(0, 500),
        content: item.contentSnippet || item.content || "",
        url: item.link.slice(0, 1000),
        source: source.name,
        category: source.category || "general",
        imageUrl: item.enclosure?.url || null,
        publishedAt: pubDate,
        isProcessed: false,
      });
    }

    return items;
  } catch (error) {
    console.error(`Failed to fetch ${source.name}:`, error);
    return [];
  }
}

export async function fetchAllNews() {
  const db = getDb();
  const sources = await db.select().from(newsSources).where(eq(newsSources.isActive, true));

  let totalNew = 0;
  for (const source of sources) {
    const articles = await fetchNewsFromSource(source);
    for (const article of articles) {
      try {
        await db.insert(newsArticles).values(article);
        totalNew++;
      } catch (e) {
        // Duplicate or error, skip
      }
    }
    await db.update(newsSources)
      .set({ lastFetchedAt: new Date() })
      .where(eq(newsSources.id, source.id));
  }

  return totalNew;
}

export async function getUnprocessedNews(limit = 10) {
  const db = getDb();
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  return db.select()
    .from(newsArticles)
    .where(
      and(
        eq(newsArticles.isProcessed, false),
        gte(newsArticles.publishedAt, since)
      )
    )
    .orderBy(desc(newsArticles.publishedAt))
    .limit(limit);
}

export async function markNewsProcessed(id: number) {
  const db = getDb();
  await db.update(newsArticles)
    .set({ isProcessed: true })
    .where(eq(newsArticles.id, id));
}
