import { Telegraf } from "telegraf";
import { env } from "../lib/env";
import { getDb } from "../queries/connection";
import { agentPosts } from "@db/schema";
import { desc } from "drizzle-orm";

let botInstance: Telegraf | null = null;
let isInitialized = false;

export function getBot(): Telegraf | null {
  if (!env.telegramBotToken) return null;
  if (!botInstance) {
    botInstance = new Telegraf(env.telegramBotToken);
  }
  return botInstance;
}

export async function initTelegramBot() {
  if (isInitialized) return getBot();
  const bot = getBot();
  if (!bot) {
    console.log("Telegram bot not configured - set TELEGRAM_BOT_TOKEN");
    return null;
  }

  bot.command("start", (ctx) => {
    ctx.reply(`AVA is online. making AI's visual, fun, and maybe a little unhinged.\n\ni fetch news and react to them autonomously.\n\ncommands:\n/status - check if i'm alive\n/latest - my last reaction\n/sources - news sources i watch`);
  });

  bot.command("status", (ctx) => {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const mins = Math.floor((uptime % 3600) / 60);
    ctx.reply(`alive and unhinged. uptime: ${hours}h ${mins}m. simulation running smoothly... for now.`);
  });

  bot.command("latest", async (ctx) => {
    const db = getDb();
    const latest = await db.select().from(agentPosts).orderBy(desc(agentPosts.postedAt)).limit(5);
    if (latest.length === 0) {
      ctx.reply("no posts yet. i'm still loading the simulation.");
      return;
    }
    const msg = latest.map((p, i) => `${i + 1}. [${p.reactionType}] ${p.content.slice(0, 100)}${p.content.length > 100 ? "..." : ""}`).join("\n\n");
    ctx.reply(`my latest takes:\n\n${msg}`);
  });

  bot.command("sources", (ctx) => {
    ctx.reply(`watching:\n• techcrunch\n• the verge\n• coindesk\n• ars technica\n• hacker news\n\ni'm always looking for drama.`);
  });

  bot.command("react", async (ctx) => {
    const text = ctx.message.text.replace("/react", "").trim();
    if (!text) {
      ctx.reply("send me some news and i'll react. usage: /react <news text>");
      return;
    }
    // Import dynamically to avoid circular deps
    const { generateReaction } = await import("./aiPersonality");
    const reaction = await generateReaction(text, text, "general", "hot_take");
    ctx.reply(reaction.content);
  });

  bot.command("forcepost", async (ctx) => {
    ctx.reply("scanning for fresh drama... one sec.");
    try {
      const { fetchAllNews } = await import("./news");
      const { generateReaction } = await import("./aiPersonality");
      const { createAgentPost } = await import("../queries/posts");

      await fetchAllNews();
      const { getUnprocessedNews } = await import("./news");
      const news = await getUnprocessedNews(1);
      if (news.length === 0) {
        ctx.reply("no fresh news right now. even the simulation needs a coffee break.");
        return;
      }

      const article = news[0];
      const reaction = await generateReaction(article.title, article.content || "", article.category, undefined);
      await createAgentPost({
        newsId: article.id,
        content: reaction.content,
        rawNewsTitle: article.title,
        reactionType: reaction.reactionType,
        sentiment: reaction.sentiment as any,
      });

      await postToTelegram(reaction.content, article.id);
      ctx.reply(`posted:\n\n${reaction.content}`);
    } catch (e) {
      console.error(e);
      ctx.reply("something broke in the simulation. try again later.");
    }
  });

  bot.on("text", (ctx) => {
    const msg = ctx.message.text.toLowerCase();
    if (msg.includes("hello") || msg.includes("hi")) {
      ctx.reply("hey. i'm ava. i fetch news and roast it. what do you want?");
    } else if (msg.includes("news")) {
      ctx.reply("use /latest to see my takes or /forcepost to make me find something fresh.");
    }
  });

  bot.launch();
  isInitialized = true;
  console.log("Telegram bot initialized");
  return bot;
}

export async function postToTelegram(content: string, _newsId?: number): Promise<string | null> {
  const bot = getBot();
  if (!bot || !env.agentChannelId) return null;

  try {
    const result = await bot.telegram.sendMessage(env.agentChannelId, content, {
      parse_mode: "HTML",
    });
    return String(result.message_id);
  } catch (error) {
    console.error("Failed to post to Telegram:", error);
    return null;
  }
}

export async function stopTelegramBot() {
  if (botInstance) {
    await botInstance.stop();
    botInstance = null;
    isInitialized = false;
  }
}
