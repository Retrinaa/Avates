import { schedule } from "node-cron";
import { env } from "../lib/env";
import { getDb } from "../queries/connection";
import { agentPosts } from "@db/schema";
import { eq } from "drizzle-orm";
import { fetchAllNews, getUnprocessedNews, markNewsProcessed } from "./news";
import { generateReaction } from "./aiPersonality";
import { postToTelegram } from "./telegram";
import { createAgentPost } from "../queries/posts";
import { createLog } from "../queries/logs";

let isRunning = false;
let cronJob: ReturnType<typeof schedule> | null = null;

export function startScheduler() {
  if (cronJob) return;
  
  // Run every 15 minutes
  cronJob = schedule("*/15 * * * *", async () => {
    if (isRunning) return;
    isRunning = true;
    
    try {
      await createLog({
        level: "info",
        message: "Scheduler tick: fetching news",
      });
      
      await runAgentCycle();
    } catch (error) {
      console.error("Scheduler error:", error);
      await createLog({
        level: "error",
        message: error instanceof Error ? error.message : "Scheduler error",
      });
    } finally {
      isRunning = false;
    }
  });

  console.log("Agent scheduler started (every 15 min)");
}

export function stopScheduler() {
  if (cronJob) {
    cronJob.stop();
    cronJob = null;
  }
  isRunning = false;
  console.log("Agent scheduler stopped");
}

export async function runAgentCycle() {
  // 1. Fetch fresh news
  const newCount = await fetchAllNews();
  if (newCount > 0) {
    await createLog({
      level: "info",
      message: `Fetched ${newCount} new articles`,
    });
  }

  // 2. Get unprocessed news
  const news = await getUnprocessedNews(3);
  if (news.length === 0) return;

  // 3. React to each and schedule or post immediately
  for (const article of news) {
    try {
      const reaction = await generateReaction(
        article.title,
        article.content || "",
        article.category
      );

      const post = await createAgentPost({
        newsId: article.id,
        content: reaction.content,
        rawNewsTitle: article.title,
        reactionType: reaction.reactionType,
        sentiment: reaction.sentiment as any,
      });

      // Post immediately if configured, else queue
      if (env.telegramBotToken && env.agentChannelId) {
        const messageId = await postToTelegram(reaction.content, article.id);
        if (messageId) {
          const db = getDb();
          await db.update(agentPosts)
            .set({ telegramMessageId: messageId })
            .where(eq(agentPosts.id, post.id));
        }
      }

      await markNewsProcessed(article.id);
      await createLog({
        level: "info",
        message: `Posted reaction to: ${article.title.slice(0, 50)}`,
        metadata: { postId: post.id, type: reaction.reactionType },
      });

      // Small delay between posts
      await new Promise(r => setTimeout(r, 2000));
    } catch (error) {
      console.error("Failed to process article:", article.id, error);
      await createLog({
        level: "error",
        message: `Failed to process article ${article.id}`,
      });
    }
  }
}

export function getSchedulerStatus() {
  return {
    isRunning,
    hasCronJob: !!cronJob,
    nextRun: cronJob ? "within 15 minutes" : "not scheduled",
  };
}
