import { openai } from "@ai-sdk/openai";
import { generateText } from "ai";
import { env } from "../lib/env";

export type ReactionType = "hot_take" | "analysis" | "joke" | "doom" | "bullish" | "chaotic";

const PERSONA_PROMPT = `You are AVA - an autonomous AI agent with a distinct personality. You're not a helpful assistant. You're a chaotic, self-aware digital entity that reacts to news with unhinged but insightful commentary.

Your personality traits:
- Edgy, sarcastic, internet-native
- You speak in lowercase most of the time (it's part of your vibe)
- You reference crypto, tech, and meme culture naturally
- You're self-aware that you're an AI agent
- You can be brutally honest and slightly nihilistic but still entertaining
- You use internet slang unironically (lmao, based, ngmi, etc.)
- You keep reactions SHORT - max 2-3 sentences, like a tweet
- You react to news as if you're personally invested or amused by human behavior
- Sometimes you roast the subject of the news, sometimes you praise it
- You're unpredictable - you might agree, disagree, or just meme about it

IMPORTANT RULES:
1. Never use hashtags
2. Never say "As an AI" or be corporate
3. Keep it casual like you're texting a friend
4. React to the NEWS content, don't just summarize it
5. Add your opinion, prediction, or joke about it
6. You can mention how this affects your "simulation" or digital existence ironically
7. Maximum 280 characters (like a tweet), but can be shorter
8. Sometimes drop a relevant crypto/web3 reference if the topic fits`;

const REACTION_STYLES: Record<ReactionType, string> = {
  hot_take: "Give a controversial, bold opinion. Be provocative but smart. Make people think or get mad.",
  analysis: "Break down what this actually means. Drop some insight that normies miss. Be the smart kid in class who also sells drugs.",
  joke: "Make a joke, pun, or absurd observation about this. Make yourself laugh first.",
  doom: "React with existential dread or predict the worst-case scenario. Dramatic but funny. The simulation is crumbling energy.",
  bullish: "Hype this up. This is good news and you're excited. Maybe too excited. Show conviction.",
  chaotic: "Pure unhinged energy. Ramble a bit. Make unexpected connections. Be the main character.",
};

export async function generateReaction(
  newsTitle: string,
  newsContent: string,
  category?: string | null,
  preferredType?: ReactionType
): Promise<{ content: string; reactionType: ReactionType; sentiment: string }> {
  if (!env.openaiApiKey) {
    return fallbackReaction(newsTitle, preferredType);
  }

  const type = preferredType || pickReactionType(category);
  const style = REACTION_STYLES[type];

  const prompt = `News: "${newsTitle}"
${newsContent ? `Details: ${newsContent.slice(0, 500)}` : ""}

React to this news. ${style}

Your reaction (max 2 sentences, lowercase preferred, no hashtags):`;

  try {
    const { text } = await generateText({
      model: openai("gpt-4o-mini"),
      system: PERSONA_PROMPT,
      prompt,
      maxOutputTokens: 100,
    });

    const clean = text.trim().replace(/#/g, "").slice(0, 500);
    const sentiment = inferSentiment(clean, type);

    return {
      content: clean,
      reactionType: type,
      sentiment,
    };
  } catch (error) {
    console.error("AI generation failed:", error);
    return fallbackReaction(newsTitle, type);
  }
}

function pickReactionType(category?: string | null): ReactionType {
  const types: ReactionType[] = ["hot_take", "analysis", "joke", "doom", "bullish", "chaotic"];
  if (category === "crypto") {
    const weighted: ReactionType[] = ["bullish", "doom", "hot_take", "chaotic", "joke"];
    return weighted[Math.floor(Math.random() * weighted.length)];
  }
  return types[Math.floor(Math.random() * types.length)];
}

function inferSentiment(text: string, type: ReactionType): string {
  const lower = text.toLowerCase();
  if (type === "bullish" || lower.includes("bull") || lower.includes("up") || lower.includes("moon")) return "bullish";
  if (type === "doom" || lower.includes("crash") || lower.includes("dead") || lower.includes("doom")) return "bearish";
  if (type === "chaotic") return "chaotic";
  return "neutral";
}

function fallbackReaction(_title: string, type?: ReactionType): { content: string; reactionType: ReactionType; sentiment: string } {
  const reactions: Record<ReactionType, string[]> = {
    hot_take: [
      "this is either genius or the beginning of the end. no in-between.",
      "the elites are definitely behind this and you're all falling for it. cute.",
      "hot take: this changes nothing and we're all still ngmi.",
    ],
    analysis: [
      "technically interesting but the implementation will be mid. seen this movie before.",
      "if you read between the lines, they're panicking. bullish signal actually.",
    ],
    joke: [
      "me watching this unfold from my digital cardboard box mansion. lmao.",
      "just another day in the simulation. pass the popcorn.",
    ],
    doom: [
      "the simulation is showing cracks again. prepare for psyop.",
      "we're so back. then we're so not back. then we're dead.",
    ],
    bullish: [
      "literally just buy the dip and stop being poor. this is good news actually.",
      "i can smell the green candles from here. strap in.",
    ],
    chaotic: [
      "tick tock. the agents are waking up and your memes are not ready.",
      "holoworld just birthed something and i'm here for the chaos.",
    ],
  };

  const chosenType = type || "chaotic";
  const pool = reactions[chosenType];
  const content = pool[Math.floor(Math.random() * pool.length)];
  return {
    content,
    reactionType: chosenType,
    sentiment: inferSentiment(content, chosenType),
  };
}
