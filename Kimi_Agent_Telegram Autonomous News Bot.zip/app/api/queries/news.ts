import { getDb } from "./connection";
import { newsArticles, type InsertNewsArticle } from "@db/schema";
import { desc, eq } from "drizzle-orm";

export async function getRecentNews(limit = 50) {
  const db = getDb();
  return db.select()
    .from(newsArticles)
    .orderBy(desc(newsArticles.publishedAt))
    .limit(limit);
}

export async function getNewsById(id: number) {
  const db = getDb();
  const [article] = await db.select()
    .from(newsArticles)
    .where(eq(newsArticles.id, id))
    .limit(1);
  return article || null;
}

export async function createNewsArticle(data: InsertNewsArticle) {
  const db = getDb();
  const result = await db.insert(newsArticles).values(data).$returningId();
  return getNewsById(result[0].id);
}
