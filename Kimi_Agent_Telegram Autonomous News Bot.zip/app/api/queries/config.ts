import { getDb } from "./connection";
import { agentConfigs } from "@db/schema";
import { eq } from "drizzle-orm";

export async function getConfig(key: string): Promise<string | null> {
  const db = getDb();
  const [config] = await db.select()
    .from(agentConfigs)
    .where(eq(agentConfigs.key, key))
    .limit(1);
  return config?.value ?? null;
}

export async function setConfig(key: string, value: string) {
  const db = getDb();
  await db.insert(agentConfigs)
    .values({ key, value })
    .onDuplicateKeyUpdate({
      set: { value, updatedAt: new Date() },
    });
}

export async function getAllConfigs() {
  const db = getDb();
  return db.select().from(agentConfigs);
}
