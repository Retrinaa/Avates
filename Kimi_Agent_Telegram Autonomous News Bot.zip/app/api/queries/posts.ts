import { getDb } from "./connection";
import { agentPosts, type InsertAgentPost } from "@db/schema";
import { desc, eq } from "drizzle-orm";

export async function getRecentPosts(limit = 50) {
  const db = getDb();
  return db.select()
    .from(agentPosts)
    .orderBy(desc(agentPosts.postedAt))
    .limit(limit);
}

export async function getPostById(id: number) {
  const db = getDb();
  const [post] = await db.select()
    .from(agentPosts)
    .where(eq(agentPosts.id, id))
    .limit(1);
  return post || null;
}

export async function createAgentPost(data: InsertAgentPost) {
  const db = getDb();
  const result = await db.insert(agentPosts).values(data).$returningId();
  const post = await getPostById(result[0].id);
  if (!post) throw new Error("Failed to create post");
  return post;
}

export async function getPostsByNewsId(newsId: number) {
  const db = getDb();
  return db.select()
    .from(agentPosts)
    .where(eq(agentPosts.newsId, newsId))
    .orderBy(desc(agentPosts.postedAt));
}
