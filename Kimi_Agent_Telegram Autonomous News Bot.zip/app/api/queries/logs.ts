import { getDb } from "./connection";
import { agentLogs, type InsertAgentLog } from "@db/schema";
import { desc } from "drizzle-orm";

export async function getRecentLogs(limit = 100) {
  const db = getDb();
  return db.select()
    .from(agentLogs)
    .orderBy(desc(agentLogs.createdAt))
    .limit(limit);
}

export async function createLog(data: InsertAgentLog) {
  const db = getDb();
  await db.insert(agentLogs).values(data);
}
